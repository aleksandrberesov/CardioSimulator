---
id: 03-special-patterns
order: 3
title: Special Patterns
schemaVersion: 1
---

# Special Patterns

Two patterns deserve separate study because the textbook "ST elevation"
rule does not apply cleanly.

## Wellens' syndrome

Deeply inverted or biphasic T waves in **V2–V3**, recorded when the
patient is pain-free, signal a critical proximal LAD stenosis. The ECG
can look almost normal between episodes, yet the lesion is high-risk.

```ecg
pathology: wellens
lead: V3
caption: Wellens' syndrome — biphasic / deep T-wave inversion in V2–V3
```

## MI in the presence of LBBB

Left bundle branch block distorts the ST–T segment, so primary
repolarisation changes are hard to read. Apply the **Sgarbossa
criteria** — concordant ST elevation, concordant ST depression in
V1–V3, or excessively discordant ST elevation.

```ecg
pathology: lbbbmi
lead: V2
caption: Acute MI complicating LBBB — assess with Sgarbossa criteria
```

```table
id: sgarbossa
editable: false
---
| Criterion                            | Points |
|--------------------------------------|--------|
| Concordant ST elevation ≥ 1 mm       | 5      |
| Concordant ST depression V1–V3       | 3      |
| Discordant ST elevation ≥ 5 mm       | 2      |
```
