---
id: 01-anterior
order: 1
title: Anterior MI
schemaVersion: 1
---

# Localizing Anterior MI

ST-segment elevation across the **precordial leads** points to the
territory of the left anterior descending (LAD) artery.

## Lead groups

- **Septal:** V1–V2
- **Anterior:** V3–V4
- **Lateral:** V5–V6, I, aVL

ST elevation is measured at the J point relative to the TP baseline:

$$
\Delta ST = V_{J} - V_{\text{baseline}}
$$

![PQRST reference complex](assets/pqrst.svg)

Anteroseptal infarction involves V1–V4:

```ecg
pathology: anteroseptalmi
lead: V2
caption: Anteroseptal MI — ST elevation in V1–V4 (lead V2)
```

A more focal anterior MI centres on V3–V4:

```ecg
pathology: anteriormi
lead: V3
caption: Anterior MI — ST elevation maximal in V3–V4
```

When injury extends laterally, V5–V6 / I / aVL join in:

```ecg
pathology: anterolatmi
lead: V5
caption: Anterolateral MI — anterior plus lateral ST elevation
```

```table
id: anterior-leads
editable: false
---
| Territory     | Leads        | Culprit          |
|---------------|--------------|------------------|
| Septal        | V1–V2        | LAD (septal)     |
| Anterior      | V3–V4        | LAD              |
| Anterolateral | V3–V6, I, aVL| LAD / diagonal   |
```
