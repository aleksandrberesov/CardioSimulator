---
id: 02-inferior-posterior
order: 2
title: Inferior & Posterior MI
schemaVersion: 1
---

# Inferior and Posterior MI

## Inferior wall

The inferior leads **II, III and aVF** view the diaphragmatic surface,
usually supplied by the right coronary artery (RCA).

```ecg
pathology: inf
lead: aVF
caption: Inferior MI — ST elevation in II, III, aVF (lead aVF)
```

Reciprocal ST *depression* in I and aVL supports the diagnosis.

## Posterior wall

The standard 12 leads have no electrode directly over the posterior wall,
so it presents as a **mirror image** in V1–V3: tall R waves, horizontal
ST depression and upright T waves.

```ecg
pathology: posteriormi
lead: V2
caption: Posterior MI — tall R and ST depression in V1–V3 (mirror image)
```

Lateral extension shows up in I, aVL, V5–V6:

```ecg
pathology: lateralmi
lead: V6
caption: Lateral MI — ST changes in I, aVL, V5–V6
```

```table
id: inferior-recognition
editable: true
---
| Question                                   | Answer |
|--------------------------------------------|--------|
| Which leads show inferior injury?          |        |
| Which leads show reciprocal depression?    |        |
| Posterior MI mirrors into which leads?     |        |
```
