---
id: 03-third-degree
order: 3
title: Third-Degree AV Block
schemaVersion: 1
---

# Third-Degree (Complete) AV Block

In complete block **no** atrial impulses reach the ventricles. The atria
and ventricles beat independently — AV dissociation driven by a slower
escape rhythm below the level of the block.

## Hallmarks

- P waves and QRS complexes are each **regular but unrelated**: the P–P
  and R–R intervals are constant, yet the PR interval varies randomly.
- Atrial rate is faster than the ventricular escape rate.
- A junctional escape gives a narrow QRS ($\approx 40\text{–}60$ bpm); a
  ventricular escape gives a wide QRS ($\approx 20\text{–}40$ bpm).

```ecg
pathology: 3abblock
lead: II
caption: Complete heart block — independent atrial and ventricular activity
```

## Contrast: sinoatrial block

Do not confuse AV dissociation with **sinoatrial (SA) block**, where the
fault is impulse *formation or exit* at the SA node. There the whole
P–QRS–T drops out together, rather than P waves marching through an
unrelated ventricular rhythm.

```ecg
pathology: sablock
lead: II
caption: Sinoatrial block — a whole P–QRS–T cycle is missing
```

```table
id: escape-rates
editable: false
---
| Escape focus | QRS width | Typical rate |
|--------------|-----------|--------------|
| Junctional   | Narrow    | 40–60 bpm    |
| Ventricular  | Wide      | 20–40 bpm    |
```
