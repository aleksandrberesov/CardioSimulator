---
id: 02-second-degree
order: 2
title: Second-Degree AV Block
schemaVersion: 1
---

# Second-Degree AV Block

In second-degree block **some** atrial impulses fail to reach the
ventricles, so there are more P waves than QRS complexes.

## Mobitz type I (Wenckebach)

- **Progressive PR prolongation** until a P wave is dropped.
- The RR interval *shortens* just before the pause.
- Usually nodal and generally benign.

```ecg
pathology: 2abblock1
lead: II
caption: Mobitz I — PR lengthens until a non-conducted P wave (lead II)
```

## Mobitz type II

- The PR interval stays **constant**, then a P wave is suddenly dropped.
- The lesion is infranodal (His–Purkinje) — higher risk of progressing
  to complete block, especially with a wide QRS or bundle branch block.

```ecg
pathology: 2abblock2
lead: aVF
caption: Mobitz II — constant PR with an abrupt dropped beat (lead aVF)
```

```ecg
pathology: 2avblock2RBBB
lead: V1
caption: Mobitz II with right bundle branch block (lead V1)
```

High-grade (advanced) block drops two or more consecutive P waves:

```ecg
pathology: 2abblock2hg
lead: II
caption: High-grade AV block — multiple consecutive non-conducted P waves
```

## Quiz

Fill in the conduction ratio (P : QRS) you would expect for each pattern.

```table
id: conduction-ratios
editable: true
---
| Pattern              | Conduction ratio |
|----------------------|------------------|
| 3:2 Wenckebach       |                  |
| Fixed 2:1 block      |                  |
| High-grade block     |                  |
```
