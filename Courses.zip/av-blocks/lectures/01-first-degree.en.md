---
id: 01-first-degree
order: 1
title: First-Degree AV Block
schemaVersion: 1
---

# First-Degree AV Block

First-degree atrioventricular (AV) block is a **conduction delay**, not a
true block: every atrial impulse still reaches the ventricles, but
transit through the AV node is slowed.

## Diagnostic criteria

- **PR interval > 200 ms** (more than one large square at 25 mm/s).
- The PR interval is *constant* from beat to beat.
- Every P wave is followed by a QRS — conduction stays 1:1.

The PR interval is measured from the onset of the P wave to the onset of
the QRS complex:

$$
PR = t_{\text{QRS onset}} - t_{\text{P onset}}
$$

A normal value is $120\text{–}200\ \text{ms}$; anything longer defines the block.

![PQRST reference complex](assets/pqrst.svg)

```ecg
pathology: 1abblock
lead: II
caption: First-degree AV block — prolonged but constant PR interval (lead II)
```

## Clinical note

Isolated first-degree block is usually benign and is common in athletes
from high vagal tone. It seldom needs treatment, but a markedly long PR
can be the earliest sign of progressive conduction-system disease.

```table
id: av-block-degrees
editable: false
---
| Degree | Hallmark                         | Risk          |
|--------|----------------------------------|---------------|
| 1°     | PR > 200 ms, all P conduct       | Low           |
| 2°     | Some P waves dropped             | Variable      |
| 3°     | No P–QRS relationship            | High          |
```
