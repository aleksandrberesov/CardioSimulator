---
id: 02-wide-complex
order: 2
title: Wide-Complex Tachycardias
schemaVersion: 1
---

# Wide-Complex Tachycardias

A wide QRS ($\ge 120\ \text{ms}$) with a fast rate is **ventricular
tachycardia until proven otherwise** — treat accordingly when the patient
is unstable.

## Monomorphic VT

Uniform, broad complexes at a regular fast rate:

```ecg
pathology: vt
lead: II
caption: Monomorphic ventricular tachycardia — uniform wide complexes
```

```ecg
pathology: tach
lead: V1
caption: Ventricular tachycardia viewed in a precordial lead
```

## Ventricular flutter

A near-sinusoidal waveform at ~250–300/min, the transitional rhythm
between rapid VT and fibrillation:

```ecg
pathology: ventrflut
lead: II
caption: Ventricular flutter — sinusoidal, ~250–300/min
```

Features that favour VT over SVT with aberrancy include AV dissociation,
fusion/capture beats, and very broad QRS.

```table
id: vt-vs-svt
editable: false
---
| Feature           | Favours VT |
|-------------------|------------|
| AV dissociation   | Yes        |
| Capture/fusion    | Yes        |
| QRS > 140 ms      | Yes        |
```
