---
id: 03-malignant
order: 3
title: Malignant Ventricular Rhythms
schemaVersion: 1
---

# Malignant Ventricular Rhythms

These rhythms are immediately life-threatening and demand defibrillation
or correction of the trigger.

## Torsades de pointes

A polymorphic VT in which the QRS axis "twists" around the baseline,
arising on a background of a **prolonged QT interval**. Correct
magnesium, potassium and offending drugs.

```ecg
pathology: tacht
lead: II
caption: Torsades de pointes — QRS twisting around the baseline
```

## Ventricular fibrillation

Chaotic, disorganised electrical activity with no effective contraction —
the rhythm of cardiac arrest:

```ecg
pathology: fibv
lead: II
caption: Ventricular fibrillation — chaotic, no organised QRS
```

The QT that predisposes to torsades is rate-corrected with Bazett's
formula:

$$
QTc = \frac{QT}{\sqrt{RR}}
$$

```table
id: malignant-response
editable: false
---
| Rhythm    | Pulse? | First action            |
|-----------|--------|-------------------------|
| Torsades  | Maybe  | IV magnesium / defib    |
| VF        | No     | Immediate defibrillation|
```
