---
id: 01-narrow-complex
order: 1
title: Narrow-Complex Tachycardias
schemaVersion: 1
---

# Narrow-Complex Tachycardias

A narrow QRS ($< 120\ \text{ms}$) means the ventricles are activated through
the normal His–Purkinje system, so the arrhythmia arises **at or above**
the AV node (supraventricular).

## Regular

Supraventricular tachycardia (SVT) is regular with hidden or retrograde
P waves:

```ecg
pathology: tachsv
lead: II
caption: Supraventricular tachycardia — regular narrow complexes
```

AV nodal reentrant tachycardia uses a re-entry circuit within the node:

```ecg
pathology: avreentrtach
lead: II
caption: AV nodal reentrant tachycardia (AVNRT)
```

Atrial flutter shows sawtooth F waves, classically at ~300/min with 2:1
conduction:

```ecg
pathology: atrflu
lead: II
caption: Atrial flutter — sawtooth flutter waves
```

## Irregular

Atrial fibrillation is irregularly irregular with no discrete P waves:

```ecg
pathology: fib
lead: II
caption: Atrial fibrillation — irregularly irregular, no P waves
```

```table
id: narrow-rhythm
editable: true
---
| Rhythm   | Regular? | P-wave morphology |
|----------|----------|-------------------|
| SVT      |          |                   |
| Flutter  |          |                   |
| AF       |          |                   |
```
