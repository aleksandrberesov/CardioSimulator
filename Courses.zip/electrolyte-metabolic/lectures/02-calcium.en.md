---
id: 02-calcium
order: 2
title: Calcium Disturbances
schemaVersion: 1
---

# Calcium Disturbances

Calcium chiefly governs the plateau phase of the action potential, so it
moves the **ST segment** and therefore the QT interval — with little
effect on T-wave shape.

## Hypercalcemia

A short ST segment shortens the QT:

```ecg
pathology: sinhypcal
lead: II
caption: Hypercalcemia — short ST segment, short QT
```

## Hypocalcemia

A long ST segment stretches the QT, with the T wave left largely
untouched:

```ecg
pathology: sinhypocal
lead: II
caption: Hypocalcemia — long ST segment, prolonged QT
```

Contrast this with potassium, which deforms the T wave itself. Calcium
moves the segment *before* the T wave.

```table
id: calcium
editable: false
---
| Disturbance   | ST segment | QT interval |
|---------------|------------|-------------|
| Hypercalcemia | short      | short       |
| Hypocalcemia  | long       | long        |
```
