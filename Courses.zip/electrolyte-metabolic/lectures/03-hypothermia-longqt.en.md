---
id: 03-hypothermia-longqt
order: 3
title: Hypothermia & Long-QT
schemaVersion: 1
---

# Hypothermia and the Long-QT State

## Hypothermia

The hallmark is the **Osborn (J) wave** — a positive deflection at the
J point — together with bradycardia, tremor artifact and prolonged
intervals.

```ecg
pathology: sinhypotherm
lead: II
caption: Hypothermia — Osborn (J) wave at the J point
```

## Long-QT

A prolonged QT, whether congenital, drug-induced or electrolyte-driven,
is the substrate for torsades de pointes. Always rate-correct:

$$
QTc = \frac{QT}{\sqrt{RR}}
$$

```ecg
pathology: sinlongqt
lead: II
caption: Prolonged QT interval in sinus rhythm
```

A $QTc > 500\ \text{ms}$ markedly raises the risk of polymorphic VT.

```table
id: qtc-risk
editable: false
---
| QTc (ms) | Interpretation     |
|----------|--------------------|
| < 440    | Normal             |
| 440–500  | Borderline / long  |
| > 500    | High torsades risk |
```
