---
id: 01-potassium
order: 1
title: Potassium Disturbances
schemaVersion: 1
---

# Potassium Disturbances

Potassium sets the resting membrane potential, so its derangements show
up first in repolarisation (the **T wave**) and conduction.

## Hyperkalemia

A progression with rising $[K^+]$:

1. Tall, peaked, narrow-based **T waves**.
2. Flattening P waves and PR prolongation.
3. QRS widening, ultimately a sine-wave pattern.

```ecg
pathology: synhy
lead: II
caption: Hyperkalemia — tall peaked T waves with broadening QRS
```

## Hypokalemia

Low $[K^+]$ does the opposite — repolarisation drags out:

- Flattened T waves and prominent **U waves**.
- ST depression and a long apparent QT.

```ecg
pathology: sinhypokal
lead: II
caption: Hypokalemia — flattened T with prominent U wave
```

```table
id: potassium
editable: true
---
| Disturbance  | T wave | Other clue   |
|--------------|--------|--------------|
| Hyperkalemia |        |              |
| Hypokalemia  |        |              |
```
