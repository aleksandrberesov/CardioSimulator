---
id: 01-atrial
order: 1
title: Atrial Enlargement
schemaVersion: 1
---

# Atrial Enlargement

Atrial enlargement reshapes the **P wave**, whose first half is the right
atrium and second half the left.

## Right atrial enlargement

Tall, peaked P waves ($> 2.5\ \text{mm}$) in II, III, aVF — "P pulmonale".

```ecg
pathology: rigthatrhyper
lead: II
caption: Right atrial enlargement — tall peaked P wave (P pulmonale)
```

## Left atrial enlargement

A broad, notched P wave ($> 120\ \text{ms}$) in II and a deep terminal
negativity in V1 — "P mitrale".

```ecg
pathology: leftatrhyper
lead: II
caption: Left atrial enlargement — broad notched P wave (P mitrale)
```

## Biatrial enlargement

Both patterns combine — tall *and* wide P waves:

```ecg
pathology: biatrenlarg
lead: II
caption: Biatrial enlargement — tall and broad P wave
```

```table
id: atrial-p-wave
editable: false
---
| Chamber | Lead | P-wave change       |
|---------|------|---------------------|
| RA      | II   | tall, peaked > 2.5mm|
| LA      | V1   | deep terminal trough|
| Both    | II   | tall + wide         |
```
