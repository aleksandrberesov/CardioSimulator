---
id: 03-biventricular
order: 3
title: Biventricular Hypertrophy
schemaVersion: 1
---

# Biventricular Hypertrophy

When both ventricles hypertrophy, their opposing forces partly cancel, so
the ECG can be deceptively unimpressive — or show a mixture of left- and
right-sided clues at once.

## Clues to look for

- Tall precordial voltages (LVH) **plus** right-axis deviation (RVH).
- Large equiphasic QRS complexes in the mid-precordial leads
  (Katz–Wachtel phenomenon).
- Signs of biatrial enlargement frequently coexist.

```ecg
pathology: biventrhyper
lead: V3
caption: Biventricular hypertrophy — large equiphasic complexes (Katz–Wachtel)
```

```ecg
pathology: biventrhyper
lead: V1
caption: Biventricular hypertrophy — right-sided voltage with left-sided clues
```

```table
id: biventricular
editable: false
---
| Sign                       | Points toward |
|----------------------------|---------------|
| Tall R in V5–V6            | LV            |
| Dominant R in V1 / RAD     | RV            |
| Equiphasic mid-precordium  | Both          |
```
