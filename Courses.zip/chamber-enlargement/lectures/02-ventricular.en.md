---
id: 02-ventricular
order: 2
title: Ventricular Hypertrophy
schemaVersion: 1
---

# Ventricular Hypertrophy

Increased muscle mass shifts the QRS axis toward the hypertrophied side
and deepens or heightens the precordial voltages.

## Left ventricular hypertrophy

Use the Sokolow–Lyon voltage criterion:

$$
S_{V1} + R_{V5\,\text{or}\,V6} > 35\ \text{mm}
$$

```ecg
pathology: synlvht
lead: V5
caption: LVH — tall R wave in V5 with strain pattern
```

## Right ventricular hypertrophy

Dominant R in V1, right-axis deviation, and a deep S in V6:

```ecg
pathology: synrvht
lead: V1
caption: RVH — dominant R wave in V1
```

A repolarisation "strain" pattern (down-sloping ST with asymmetric T
inversion) often accompanies advanced hypertrophy.

```table
id: lvh-vs-rvh
editable: true
---
| Feature      | LVH | RVH |
|--------------|-----|-----|
| Axis         |     |     |
| Tall R lead  |     |     |
| Deep S lead  |     |     |
```
