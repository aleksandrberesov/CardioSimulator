---
id: 02-lbbb
order: 2
title: Left Bundle Branch Block
schemaVersion: 1
---

# Left Bundle Branch Block

Left bundle branch block reverses septal activation, producing a broad,
notched QRS and **secondary** ST–T changes that mimic ischaemia.

## Recognition

- Broad, monophasic R waves in I, V5–V6 (often notched).
- Deep QS or rS in V1.
- QRS $\ge 120\ \text{ms}$, with discordant ST–T (opposite the main QRS
  deflection).

```ecg
pathology: synblg
lead: V6
caption: LBBB — broad notched R wave in V6
```

```ecg
pathology: synblg
lead: V1
caption: LBBB — deep QS complex in V1
```

Because LBBB already distorts repolarisation, a new LBBB with ischaemic
symptoms is treated as an acute coronary equivalent.

```table
id: bbb-compare
editable: false
---
| Feature      | RBBB        | LBBB         |
|--------------|-------------|--------------|
| V1           | rSR'        | QS / rS      |
| V6           | wide S      | broad R      |
| Septal order | preserved   | reversed     |
```
