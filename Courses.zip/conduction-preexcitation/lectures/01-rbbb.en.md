---
id: 01-rbbb
order: 1
title: Right Bundle Branch Block
schemaVersion: 1
---

# Right Bundle Branch Block

When the right bundle fails, the right ventricle is depolarised late and
indirectly, widening the QRS to $\ge 120\ \text{ms}$.

## Recognition

- **rSR'** ("rabbit ears") in V1–V2.
- Wide, slurred S wave in I, V5–V6.
- QRS $\ge 120\ \text{ms}$ (incomplete if 110–120 ms).

![PQRST reference complex](assets/pqrst.svg)

```ecg
pathology: synbrg
lead: V1
caption: RBBB — rSR' pattern in V1
```

Incomplete RBBB shows the same morphology with a QRS still under 120 ms:

```ecg
pathology: incomprbbb
lead: V1
caption: Incomplete RBBB — rSR' with QRS 110–120 ms
```

```table
id: rbbb-criteria
editable: true
---
| Feature           | RBBB value |
|-------------------|------------|
| QRS duration      |            |
| V1 morphology     |            |
| Lead I S-wave     |            |
```
