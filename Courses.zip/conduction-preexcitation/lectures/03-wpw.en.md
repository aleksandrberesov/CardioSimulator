---
id: 03-wpw
order: 3
title: Ventricular Pre-excitation (WPW)
schemaVersion: 1
---

# Ventricular Pre-excitation (WPW)

In Wolff–Parkinson–White syndrome an accessory pathway (bundle of Kent)
lets the atrial impulse bypass the AV node, pre-exciting part of the
ventricle.

## The triad

- **Short PR interval** ($< 120\ \text{ms}$).
- **Delta wave** — a slurred QRS upstroke.
- **Widened QRS** from fusion of pathway and normal conduction.

```ecg
pathology: synwpw
lead: II
caption: WPW — short PR with a delta wave
```

The delta-wave polarity helps localise the accessory pathway. A right
lateral pathway, for example, shifts the early forces:

```ecg
pathology: wpwrightlat
lead: V1
caption: WPW, right lateral pathway — delta wave in V1
```

Pre-excitation matters most because it can support fast re-entry
(AVRT) — and atrial fibrillation conducting down a fast pathway is
dangerous.

```table
id: wpw-triad
editable: true
---
| Component   | Expected finding |
|-------------|------------------|
| PR interval |                  |
| QRS onset   |                  |
| QRS width   |                  |
```
